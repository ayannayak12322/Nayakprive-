import React, { useState } from 'react';

const AddProducts = () => {
  const [product, setProduct] = useState({ name: '', price: '', stock: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(product);
    alert('Product added successfully!');
    setProduct({ name: '', price: '', stock: '' });
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Add New Product</h2>
      <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
        <input
          type="text"
          placeholder="Product Name"
          className="border w-full p-2"
          value={product.name}
          onChange={(e) => setProduct({ ...product, name: e.target.value })}
        />
        <input
          type="number"
          placeholder="Price"
          className="border w-full p-2"
          value={product.price}
          onChange={(e) => setProduct({ ...product, price: e.target.value })}
        />
        <input
          type="number"
          placeholder="Stock"
          className="border w-full p-2"
          value={product.stock}
          onChange={(e) => setProduct({ ...product, stock: e.target.value })}
        />
        <button type="submit" className="bg-black text-white px-4 py-2 rounded">
          Add Product
        </button>
      </form>
    </div>
  );
};

export default AddProducts;