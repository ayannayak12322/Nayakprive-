import React, { useState } from 'react';

const Coupons = () => {
  const [code, setCode] = useState('');

  const handleAdd = () => {
    alert(`Coupon "${code}" added!`);
    setCode('');
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Coupons</h2>
      <input
        type="text"
        placeholder="Enter Coupon Code"
        className="border p-2 mr-2"
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />
      <button onClick={handleAdd} className="bg-black text-white px-4 py-2 rounded">
        Add
      </button>
    </div>
  );
};

export default Coupons;