import React from 'react';

const Dashboard = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-blue-100 p-4 rounded shadow">Total Orders</div>
        <div className="bg-green-100 p-4 rounded shadow">Total Sales</div>
        <div className="bg-yellow-100 p-4 rounded shadow">Users</div>
        <div className="bg-red-100 p-4 rounded shadow">Products</div>
      </div>
    </div>
  );
};

export default Dashboard;