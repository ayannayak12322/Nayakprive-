import React, { useState } from 'react';
import { useRouter } from 'next/router';

const Login = () => {
  const router = useRouter();
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (password === '@Artistayan123') {
      router.push('/admin/dashboard');
    } else {
      alert('Incorrect Password');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <h2 className="text-xl font-bold mb-4">Admin Login</h2>
      <input
        type="password"
        placeholder="Enter Password"
        className="border p-2 mb-4"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin} className="bg-black text-white px-4 py-2 rounded">
        Login
      </button>
    </div>
  );
};

export default Login;