import React from 'react';

const Products = () => {
  const products = [
    { id: 1, name: 'Shirt', price: 999, stock: 10 },
    { id: 2, name: 'Sneakers', price: 1999, stock: 5 }
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">All Products</h2>
      <table className="w-full table-auto border">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2">Product</th>
            <th className="p-2">Price</th>
            <th className="p-2">Stock</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id} className="border-t">
              <td className="p-2">{product.name}</td>
              <td className="p-2">₹{product.price}</td>
              <td className="p-2">{product.stock}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Products;