import React from 'react';

const Returns = () => {
  const returns = [
    { id: 1, product: 'Sneakers', reason: 'Size issue' },
    { id: 2, product: 'T-Shirt', reason: 'Defective' }
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Return Requests</h2>
      <ul className="space-y-2">
        {returns.map((r) => (
          <li key={r.id} className="border p-2 rounded">
            {r.product} - {r.reason}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Returns;