import React from 'react';

const Users = () => {
  const users = [
    { id: 1, name: 'Ayan', email: 'ayan@example.com' },
    { id: 2, name: 'Nayak', email: 'nayak@example.com' }
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">All Users</h2>
      <ul className="space-y-2">
        {users.map((user) => (
          <li key={user.id} className="border p-2 rounded">
            {user.name} - {user.email}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Users;