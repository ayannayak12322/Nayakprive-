import { useState } from "react";

export default function CartDrawer() {
  const [open, setOpen] = useState(false);

  const dummyCart = [
    { name: "Black Blazer", price: 7999, qty: 1 },
    { name: "White Sneakers", price: 3499, qty: 2 },
  ];

  const total = dummyCart.reduce((sum, item) => sum + item.price * item.qty, 0);

  return (
    <>
      {/* 🛒 Cart Icon Button */}
      <button
        onClick={() => setOpen(true)}
        className="text-white hover:text-yellow-400 transition"
      >
        🛒
      </button>

      {/* 🧾 Drawer */}
      {open && (
        <div className="fixed top-0 right-0 w-80 h-full bg-white shadow-lg z-50 p-5 transition-transform duration-300">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Your Cart</h2>
            <button onClick={() => setOpen(false)} className="text-red-500 text-xl">×</button>
          </div>

          {dummyCart.length === 0 ? (
            <p className="text-gray-600">Your cart is empty</p>
          ) : (
            <ul className="space-y-3">
              {dummyCart.map((item, i) => (
                <li key={i} className="border-b pb-2">
                  <div className="flex justify-between">
                    <span>{item.name} × {item.qty}</span>
                    <span>₹{item.price * item.qty}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-4 font-semibold text-right">
            Total: ₹{total}
          </div>

          <button className="mt-4 w-full bg-black text-white py-2 rounded hover:bg-gray-800 transition">
            Go to Checkout
          </button>
        </div>
      )}
    </>
  );
}