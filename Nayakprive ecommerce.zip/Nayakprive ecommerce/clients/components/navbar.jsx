import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="bg-black text-white px-6 py-4 flex justify-between items-center shadow-md">
      <div className="text-2xl font-bold tracking-wider">
        <span className="text-yellow-400">NAYAK</span> <span className="text-green-400">PRIVÉ</span>
      </div>
      <ul className="flex gap-5 text-sm uppercase">
        <li><Link href="/">home</Link></li>
        <li><Link href="/shop">shop</Link></li>
        <li><Link href="/cart">cart</Link></li>
        <li><Link href="/account/login">login</Link></li>
      </ul>
    </nav>
  );
}
import CartDrawer from "./cartdrawer";

export default function Navbar() {
  return (
    <nav className="bg-black text-white px-6 py-4 flex justify-between items-center shadow-md">
      <div className="text-2xl font-bold">
        <span className="text-yellow-400">nayak</span>{" "}
        <span className="text-green-400">privé</span>
      </div>

      <ul className="flex gap-5 text-sm uppercase items-center">
        <li><a href="/">home</a></li>
        <li><a href="/shop">shop</a></li>
        <li><a href="/account/login">login</a></li>
        <li><CartDrawer /></li> {/* 🔁 Cart drawer button */}
      </ul>
    </nav>
  );
}