import { useState } from "react";

export default function UpiButton() {
  const [showQR, setShowQR] = useState(false);

  const handlePayment = () => {
    setShowQR(true);
  };

  return (
    <div className="text-center mt-4">
      <button
        onClick={handlePayment}
        className="bg-green-600 text-white px-6 py-2 rounded-xl hover:bg-green-700 transition-all"
      >
        Pay via UPI
      </button>

      {showQR && (
        <div className="mt-4">
          <p className="mb-2 text-sm text-gray-600">Scan this UPI QR to pay</p>
          <img
            src="/upi-qr.png"
            alt="UPI QR Code"
            className="w-48 h-48 mx-auto border rounded"
          />
        </div>
      )}
    </div>
  );
}