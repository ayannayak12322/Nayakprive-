/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['res.cloudinary.com', 'images.unsplash.com', 'cdn.sanity.io'],
  },
  experimental: {
    serverActions: true,
  },
};

module.exports = nextConfig;