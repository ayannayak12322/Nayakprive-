import { useRouter } from "next/router";
import Head from "next/head";

export default function ProductDetail() {
  const router = useRouter();
  const { id } = router.query;

  // Later: fetch product data using `id`
  // Example: useEffect(() => fetchProduct(id), [id]);

  return (
    <>
      <Head>
        <title>Product #{id} - NAYAK PRIVÉ</title>
      </Head>
      <div className="p-6 text-center">
        <h1 className="text-4xl font-bold">Product Detail Page</h1>
        <p className="text-gray-600 mt-2">Showing details for product ID: <strong>{id}</strong></p>
        <p className="text-sm text-gray-500 mt-2">(Dynamic content will load here)</p>
      </div>
    </>
  );
}