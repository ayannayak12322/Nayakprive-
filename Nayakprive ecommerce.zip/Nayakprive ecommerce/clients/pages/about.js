import Head from "next/head";

export default function About() {
  return (
    <>
      <Head>
        <title>About Us - NAYAK PRIVÉ</title>
      </Head>
      <div className="text-center p-6">
        <h1 className="text-4xl font-bold">About Us</h1>
        <p className="text-gray-600 mt-2">Learn more about our mission & values.</p>
      </div>
    </>
  );
}