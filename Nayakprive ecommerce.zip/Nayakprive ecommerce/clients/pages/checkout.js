'use client'
import React, { useEffect, useState } from 'react';
import { toast } from 'react-hot-toast';
import { useRouter } from 'next/navigation';

const Checkout = () => {
  const [cartItems, setCartItems] = useState([]);
  const [user, setUser] = useState({ name: '', email: '', address: '', phone: '' });
  const router = useRouter();

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCartItems(storedCart);
  }, []);

  const totalPrice = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const handleChange = (e) => {
    setUser(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCheckout = () => {
    if (!user.name || !user.email || !user.address || !user.phone) {
      toast.error("Please fill all details");
      return;
    }

    // Save order (optional: send to backend later)
    localStorage.removeItem('cart');
    toast.success("Order Placed Successfully!");
    setTimeout(() => router.push('/'), 2000);
  };

  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Checkout</h1>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Customer Info Form */}
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-2">Your Details</h2>
          <input type="text" name="name" placeholder="Full Name" value={user.name} onChange={handleChange} className="w-full mb-2 p-2 border rounded" />
          <input type="email" name="email" placeholder="Email" value={user.email} onChange={handleChange} className="w-full mb-2 p-2 border rounded" />
          <input type="text" name="phone" placeholder="Phone Number" value={user.phone} onChange={handleChange} className="w-full mb-2 p-2 border rounded" />
          <textarea name="address" placeholder="Shipping Address" value={user.address} onChange={handleChange} className="w-full mb-2 p-2 border rounded" rows={4}></textarea>
          <button onClick={handleCheckout} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Place Order
          </button>
        </div>

        {/* Cart Summary */}
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-2">Order Summary</h2>
          {cartItems.map(item => (
            <div key={item.id} className="flex justify-between border-b py-2">
              <span>{item.title} x {item.quantity}</span>
              <span>₹{item.price * item.quantity}</span>
            </div>
          ))}
          <div className="flex justify-between mt-4 font-bold">
            <span>Total</span>
            <span>₹{totalPrice}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;