import Head from "next/head";

export default function Home() {
  return (
    <>
      <Head>
        <title>NAYAK PRIVÉ - Home</title>
      </Head>
      <div className="text-center p-6">
        <h1 className="text-4xl font-bold">Welcome to NAYAK PRIVÉ</h1>
        <p className="text-gray-600 mt-2">Your destination for luxury fashion.</p>
      </div>
    </>
  );
}