import Head from "next/head";

export default function Login() {
  return (
    <>
      <Head>
        <title>Login - NAYAK PRIVÉ</title>
      </Head>
      <div className="text-center p-6">
        <h1 className="text-4xl font-bold">Login</h1>
        <p className="text-gray-600 mt-2">Access your account.</p>
      </div>
    </>
  );
}