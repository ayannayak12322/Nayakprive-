// pages/myaccount.js
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

const MyAccount = () => {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('orders');

  useEffect(() => {
    // Dummy auth check
    const userData = JSON.parse(localStorage.getItem('user'));
    if (!userData) {
      router.push('/account/login');
    } else {
      setUser(userData);
    }
  }, []);

  if (!user) return null;

  return (
    <div className="min-h-screen p-6 bg-gray-100 text-gray-900">
      <div className="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4">Welcome, {user.name || "User"}!</h2>

        {/* Tab buttons */}
        <div className="flex space-x-4 mb-4">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded ${activeTab === 'orders' ? 'bg-black text-white' : 'bg-gray-200'}`}
          >
            Orders
          </button>
          <button
            onClick={() => setActiveTab('returns')}
            className={`px-4 py-2 rounded ${activeTab === 'returns' ? 'bg-black text-white' : 'bg-gray-200'}`}
          >
            Returns
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded ${activeTab === 'profile' ? 'bg-black text-white' : 'bg-gray-200'}`}
          >
            Profile
          </button>
        </div>

        {/* Tab content */}
        <div className="mt-6">
          {activeTab === 'orders' && (
            <div>
              <h3 className="text-xl font-medium mb-2">Your Orders</h3>
              <p>List of your recent orders will appear here.</p>
              {/* TODO: Replace with actual order list from backend */}
            </div>
          )}

          {activeTab === 'returns' && (
            <div>
              <h3 className="text-xl font-medium mb-2">Returns</h3>
              <p>Your return history will appear here.</p>
            </div>
          )}

          {activeTab === 'profile' && (
            <div>
              <h3 className="text-xl font-medium mb-2">Profile Information</h3>
              <p><strong>Email:</strong> {user.email}</p>
              {/* Add more fields as needed */}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MyAccount;