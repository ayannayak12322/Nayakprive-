import Head from "next/head";

export default function Register() {
  return (
    <>
      <Head>
        <title>Register - NAYAK PRIVÉ</title>
      </Head>
      <div className="text-center p-6">
        <h1 className="text-4xl font-bold">Register</h1>
        <p className="text-gray-600 mt-2">Create a new account.</p>
      </div>
    </>
  );
}