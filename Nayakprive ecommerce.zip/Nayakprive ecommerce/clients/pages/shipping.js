import Head from "next/head";

export default function Shipping() {
  return (
    <>
      <Head>
        <title>Shipping Info - NAYAK PRIVÉ</title>
      </Head>
      <div className="text-center p-6">
        <h1 className="text-4xl font-bold">Shipping Information</h1>
        <p className="text-gray-600 mt-2">Delivery timelines and costs.</p>
      </div>
    </>
  );
}