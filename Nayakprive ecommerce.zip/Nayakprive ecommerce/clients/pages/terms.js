import Head from "next/head";

export default function Terms() {
  return (
    <>
      <Head>
        <title>Terms & Conditions - NAYAK PRIVÉ</title>
      </Head>
      <div className="text-center p-6">
        <h1 className="text-4xl font-bold">Terms & Conditions</h1>
        <p className="text-gray-600 mt-2">Read our rules and policies.</p>
      </div>
    </>
  );
}