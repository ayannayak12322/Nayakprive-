'use client'
import React, { useEffect, useState } from 'react';
import ProductCard from '../components/productcard';
import { toast } from 'react-hot-toast';

const WishlistPage = () => {
  const [wishlistItems, setWishlistItems] = useState([]);

  useEffect(() => {
    const storedWishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
    setWishlistItems(storedWishlist);
  }, []);

  const removeFromWishlist = (id) => {
    const updated = wishlistItems.filter(item => item.id !== id);
    setWishlistItems(updated);
    localStorage.setItem('wishlist', JSON.stringify(updated));
    toast.success('Removed from Wishlist');
  };

  const moveToCart = (item) => {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const updatedCart = [...cart, { ...item, quantity: 1 }];
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    removeFromWishlist(item.id);
    toast.success('Moved to Cart');
  };

  return (
    <div className="p-4 min-h-screen bg-gray-50">
      <h1 className="text-2xl font-bold mb-4">Your Wishlist</h1>

      {wishlistItems.length === 0 ? (
        <p className="text-gray-500">Your wishlist is empty 😔</p>
      ) : (
        <div className="grid md:grid-cols-3 gap-4">
          {wishlistItems.map(item => (
            <div key={item.id} className="border rounded-lg p-4 shadow bg-white">
              <ProductCard product={item} hideActions />
              <div className="flex justify-between mt-2">
                <button
                  onClick={() => moveToCart(item)}
                  className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
                >
                  Move to Cart
                </button>
                <button
                  onClick={() => removeFromWishlist(item.id)}
                  className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WishlistPage;